# 🎓 CampusNav — Smart Campus Navigation Web App

A fully interactive, production-grade Smart Campus Navigation System built with vanilla HTML, CSS, and JavaScript. Designed for university students and staff to navigate campus efficiently.

---

## 📁 Project Structure

```
smart-campus-nav/
├── index.html              # Dashboard & Interactive Campus Map
├── css/
│   └── style.css           # Global styles, themes, components
├── js/
│   ├── map.js              # Canvas-based interactive campus map
│   └── app.js              # Core app logic (search, theme, modals, etc.)
└── pages/
    ├── buildings.html      # Full Buildings Directory
    ├── routes.html         # Route Planner with turn-by-turn steps
    ├── events.html         # Campus Events Calendar
    └── schedule.html       # Personal Timetable & Attendance
```

---

## ✨ Features

### 🗺️ Campus Map (index.html)
- Canvas-rendered interactive campus map with 13+ buildings
- Color-coded by category: Academic, Labs, Food, Sports, Admin
- Hover tooltips showing building name, description & floor
- Click-to-highlight buildings
- Filter by building type
- Route modal with walk/cycle/shuttle modes

### 🏛️ Buildings Directory (buildings.html)
- Card-based directory of all campus buildings
- Filter by category (Academic, Labs, Admin, Food, Sports, Hostel)
- Live search across all buildings
- Status badges: Open / Restricted / 24/7 / By Appointment

### ↯ Route Planner (routes.html)
- Point-to-point route planning between campus locations
- Turn-by-turn step-by-step directions
- Time, distance & turn count summary
- Walk / Cycle / Shuttle mode selector
- Canvas route preview map
- Popular quick-routes

### ◉ Campus Events (events.html)
- Featured event hero banner
- 7-day scrollable calendar strip with event indicators
- Filter by: Technical, Cultural, Sports, Academic
- One-click RSVP / Register buttons

### ▦ My Schedule (schedule.html)
- Weekly timetable with color-coded subjects
- Day-by-day switching (Mon–Fri)
- Live countdown timer to next class
- Today at a glance sidebar
- Attendance percentage tracker per subject with visual bars

---

## 🎨 Design System

| Token | Value |
|---|---|
| Primary BG | `#0b0e17` |
| Surface | `#12161f` |
| Accent (Green) | `#00e5a0` |
| Accent (Blue) | `#4f8cff` |
| Accent (Red) | `#ff6b6b` |
| Heading Font | Syne |
| Body Font | DM Sans |

### Light / Dark Mode
Toggle with the ◑ button in the top bar. Preference persists per session.

---

## 🚀 How to Run

1. Unzip the project folder
2. Open `index.html` in any modern browser
3. No build tools, no dependencies, no server required

> **Tip:** For best results, use Chrome or Firefox. Internet connection required for Google Fonts.

---

## 🧩 Technology Stack

- **HTML5** — Semantic markup
- **CSS3** — Custom properties, Grid, Flexbox, animations
- **Canvas API** — Interactive map rendering
- **Vanilla JavaScript** — No frameworks, no dependencies
- **Google Fonts** — Syne + DM Sans

---

## 📌 DTI Project Notes

| Field | Detail |
|---|---|
| Project Title | Smart Campus Navigation Web App |
| Domain | Web Development / UI/UX |
| Tech Stack | HTML, CSS, JavaScript (Canvas API) |
| Pages | 5 (Map, Buildings, Routes, Events, Schedule) |
| Responsive | Yes (mobile-friendly) |
| Theme | Dark + Light mode |

---

*Built with ◈ by CampusNav Team — DTI 2025*
