// ─── PRELOADER ────────────────────────────────────────────
window.addEventListener('load', () => {
  setTimeout(() => {
    document.getElementById('preloader')?.classList.add('done');
    setTimeout(() => {
      const pre = document.getElementById('preloader');
      if (pre) pre.style.display = 'none';
    }, 600);
  }, 2000);
});

// ─── SIDEBAR TOGGLE ───────────────────────────────────────
const sidebar = document.getElementById('sidebar');
const mainContent = document.getElementById('mainContent');
document.getElementById('sidebarToggle')?.addEventListener('click', () => {
  sidebar?.classList.toggle('collapsed');
});

// ─── THEME TOGGLE ─────────────────────────────────────────
let dark = true;
document.getElementById('themeToggle')?.addEventListener('click', () => {
  dark = !dark;
  document.documentElement.setAttribute('data-theme', dark ? 'dark' : 'light');
  document.dispatchEvent(new Event('themeChanged'));
});

// ─── ANIMATED COUNTERS ────────────────────────────────────
function animateCount(el, target, duration = 1200) {
  let start = 0, step = target / (duration / 16);
  const timer = setInterval(() => {
    start = Math.min(start + step, target);
    el.textContent = Math.floor(start).toLocaleString();
    if (start >= target) clearInterval(timer);
  }, 16);
}

document.querySelectorAll('[data-count]').forEach(el => {
  const target = parseInt(el.dataset.count);
  setTimeout(() => animateCount(el, target), 2200);
});

// ─── LIVE COUNT PULSE ─────────────────────────────────────
const liveEl = document.querySelector('.live-count');
if (liveEl) {
  setInterval(() => {
    const base = 3821;
    const delta = Math.floor(Math.random() * 20) - 10;
    liveEl.textContent = (base + delta).toLocaleString();
  }, 4000);
}

// ─── SEARCH ───────────────────────────────────────────────
const searchData = [
  { name: 'CSE Block', type: 'Academic Block', icon: '💻' },
  { name: 'ECE Block', type: 'Academic Block', icon: '⚡' },
  { name: 'Mechanical Block', type: 'Academic Block', icon: '⚙️' },
  { name: 'Civil Block', type: 'Academic Block', icon: '🏗️' },
  { name: 'Research Lab', type: 'Laboratory', icon: '🔬' },
  { name: 'AI/ML Lab', type: 'Laboratory', icon: '🤖' },
  { name: 'Networks Lab', type: 'Laboratory', icon: '🌐' },
  { name: 'Admin Block', type: 'Administration', icon: '🏛️' },
  { name: 'Main Cafeteria', type: 'Food & Dining', icon: '🍛' },
  { name: 'Food Court', type: 'Food & Dining', icon: '🍕' },
  { name: 'Sports Complex', type: 'Sports', icon: '🏋️' },
  { name: 'Central Library', type: 'Academic', icon: '📚' },
  { name: 'Main Auditorium', type: 'Events & Gathering', icon: '🎭' },
  { name: 'Medical Centre', type: 'Health', icon: '🏥' },
  { name: 'Boys Hostel A', type: 'Accommodation', icon: '🏠' },
  { name: 'Girls Hostel', type: 'Accommodation', icon: '🏠' },
  { name: 'ATM Block', type: 'Facility', icon: '💳' },
  { name: 'Parking Lot A', type: 'Parking', icon: '🅿️' },
];

const searchInput = document.getElementById('searchInput');
const searchResults = document.getElementById('searchResults');

searchInput?.addEventListener('input', (e) => {
  const q = e.target.value.trim().toLowerCase();
  if (!q) { searchResults.classList.remove('visible'); return; }

  const filtered = searchData.filter(d =>
    d.name.toLowerCase().includes(q) || d.type.toLowerCase().includes(q)
  ).slice(0, 6);

  if (!filtered.length) { searchResults.classList.remove('visible'); return; }

  searchResults.innerHTML = filtered.map(d => `
    <div class="search-result-item" onclick="selectResult('${d.name}')">
      <span class="sri-icon">${d.icon}</span>
      <div class="sri-info">
        <span class="sri-name">${d.name}</span>
        <span class="sri-type">${d.type}</span>
      </div>
    </div>
  `).join('');
  searchResults.classList.add('visible');
});

document.addEventListener('click', e => {
  if (!searchInput?.contains(e.target) && !searchResults?.contains(e.target)) {
    searchResults?.classList.remove('visible');
  }
});

function selectResult(name) {
  if (searchInput) searchInput.value = name;
  searchResults?.classList.remove('visible');
  if (typeof highlightBuilding === 'function') highlightBuilding(name);
}

// ─── ROUTE MODAL ──────────────────────────────────────────
function openRoute() {
  const tooltip = document.getElementById('mapTooltip');
  const dest = tooltip?.querySelector('.tooltip-name')?.textContent || '';
  const destInput = document.getElementById('destInput');
  if (destInput) destInput.value = dest;
  document.getElementById('routeModal')?.classList.add('open');
}

function closeModal() {
  document.getElementById('routeModal')?.classList.remove('open');
}

function startNavigation() {
  const dest = document.getElementById('destInput')?.value;
  if (!dest) { alert('Please enter a destination.'); return; }
  showToast(`🧭 Navigating to ${dest}...`);
  closeModal();
}

// Clicking overlay closes modal
document.getElementById('routeModal')?.addEventListener('click', e => {
  if (e.target === e.currentTarget) closeModal();
});

// Route option buttons
document.querySelectorAll('.route-opt').forEach(btn => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.route-opt').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
  });
});

// ─── TOAST ────────────────────────────────────────────────
function showToast(msg) {
  let toast = document.getElementById('toast');
  if (!toast) {
    toast = document.createElement('div');
    toast.id = 'toast';
    toast.style.cssText = `
      position:fixed;bottom:30px;right:30px;z-index:999;
      background:#00e5a0;color:#000;font-weight:700;
      padding:12px 22px;border-radius:12px;font-size:14px;
      box-shadow:0 4px 20px rgba(0,229,160,0.4);
      transform:translateY(60px);opacity:0;
      transition:all 0.3s cubic-bezier(.34,1.56,.64,1);
      font-family:'DM Sans',sans-serif;
    `;
    document.body.appendChild(toast);
  }
  toast.textContent = msg;
  setTimeout(() => { toast.style.transform = 'translateY(0)'; toast.style.opacity = '1'; }, 10);
  setTimeout(() => { toast.style.transform = 'translateY(60px)'; toast.style.opacity = '0'; }, 3000);
}

// ─── KEYBOARD SHORTCUT ────────────────────────────────────
document.addEventListener('keydown', e => {
  if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
    e.preventDefault();
    searchInput?.focus();
  }
  if (e.key === 'Escape') closeModal();
});
