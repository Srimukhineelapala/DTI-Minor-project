// ─── CAMPUS MAP DATA ──────────────────────────────────────
const buildings = [
  // Academic
  { id: 'cse', name: 'CSE Block', type: 'academic', x: 120, y: 80, w: 120, h: 80, icon: '💻', floor: '1–4', desc: 'Computer Science & Engineering' },
  { id: 'ece', name: 'ECE Block', type: 'academic', x: 280, y: 80, w: 100, h: 80, icon: '⚡', floor: '1–3', desc: 'Electronics & Communication' },
  { id: 'mech', name: 'Mech Block', type: 'academic', x: 420, y: 80, w: 100, h: 80, icon: '⚙️', floor: '1–4', desc: 'Mechanical Engineering' },
  { id: 'civil', name: 'Civil Block', type: 'academic', x: 560, y: 80, w: 100, h: 80, icon: '🏗️', floor: '1–3', desc: 'Civil Engineering' },
  // Labs
  { id: 'lab1', name: 'Research Lab', type: 'labs', x: 120, y: 220, w: 130, h: 70, icon: '🔬', floor: '1–2', desc: 'Research & Innovation Lab' },
  { id: 'lab2', name: 'AI/ML Lab', type: 'labs', x: 290, y: 220, w: 110, h: 70, icon: '🤖', floor: '3', desc: 'Artificial Intelligence Lab' },
  { id: 'lab3', name: 'Networks Lab', type: 'labs', x: 440, y: 220, w: 110, h: 70, icon: '🌐', floor: '2', desc: 'Computer Networks Lab' },
  // Admin
  { id: 'admin', name: 'Admin Block', type: 'admin', x: 680, y: 80, w: 110, h: 130, icon: '🏛️', floor: '1–3', desc: 'Administration & Offices' },
  // Food
  { id: 'cafe1', name: 'Main Cafeteria', type: 'food', x: 120, y: 350, w: 130, h: 70, icon: '🍛', floor: 'G', desc: 'Main dining hall' },
  { id: 'cafe2', name: 'Food Court', type: 'food', x: 290, y: 350, w: 100, h: 70, icon: '🍕', floor: 'G', desc: 'Multi-cuisine food court' },
  // Sports
  { id: 'sports', name: 'Sports Complex', type: 'sports', x: 460, y: 350, w: 160, h: 100, icon: '🏋️', floor: 'G–1', desc: 'Gym, courts & pool' },
  // Special
  { id: 'lib', name: 'Library', type: 'academic', x: 680, y: 260, w: 110, h: 100, icon: '📚', floor: '1–4', desc: 'Central Library — 24/7' },
  { id: 'audi', name: 'Auditorium', type: 'admin', x: 660, y: 390, w: 130, h: 80, icon: '🎭', floor: 'G', desc: 'Main Auditorium — 1500 seats' },
];

const paths = [
  // Main horizontal road
  { x1: 80, y1: 200, x2: 820, y2: 200 },
  // Main vertical road
  { x1: 420, y1: 50, x2: 420, y2: 480 },
  // Secondary
  { x1: 80, y1: 330, x2: 820, y2: 330 },
  { x1: 260, y1: 50, x2: 260, y2: 480 },
  { x1: 660, y1: 50, x2: 660, y2: 480 },
];

// ─── COLORS ───────────────────────────────────────────────
const colors = {
  academic: { fill: 'rgba(79,140,255,0.25)', stroke: '#4f8cff', label: '#4f8cff' },
  labs:     { fill: 'rgba(168,85,247,0.25)', stroke: '#a855f7', label: '#a855f7' },
  food:     { fill: 'rgba(245,158,11,0.25)', stroke: '#f59e0b', label: '#f59e0b' },
  sports:   { fill: 'rgba(0,229,160,0.25)',  stroke: '#00e5a0', label: '#00e5a0' },
  admin:    { fill: 'rgba(255,107,107,0.25)', stroke: '#ff6b6b', label: '#ff6b6b' },
};

// ─── STATE ────────────────────────────────────────────────
let canvas, ctx, activeFilter = 'all', hoveredBuilding = null, highlightedId = null;
let scaleX = 1, scaleY = 1;

function isDark() {
  return !document.documentElement.getAttribute('data-theme') ||
    document.documentElement.getAttribute('data-theme') === 'dark';
}

// ─── DRAW ─────────────────────────────────────────────────
function drawMap() {
  const W = canvas.width, H = canvas.height;
  ctx.clearRect(0, 0, W, H);

  // Background
  ctx.fillStyle = isDark() ? '#0f1320' : '#e8ecf5';
  ctx.fillRect(0, 0, W, H);

  // Grid
  ctx.strokeStyle = isDark() ? 'rgba(255,255,255,0.03)' : 'rgba(0,0,0,0.05)';
  ctx.lineWidth = 1;
  for (let x = 0; x < W; x += 40) {
    ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, H); ctx.stroke();
  }
  for (let y = 0; y < H; y += 40) {
    ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(W, y); ctx.stroke();
  }

  // Paths (roads)
  ctx.strokeStyle = isDark() ? 'rgba(255,255,255,0.08)' : 'rgba(0,0,0,0.08)';
  ctx.lineWidth = 12;
  ctx.lineCap = 'round';
  paths.forEach(p => {
    ctx.beginPath();
    ctx.moveTo(p.x1, p.y1);
    ctx.lineTo(p.x2, p.y2);
    ctx.stroke();
  });

  // Road center lines
  ctx.strokeStyle = isDark() ? 'rgba(255,255,255,0.04)' : 'rgba(0,0,0,0.06)';
  ctx.lineWidth = 1;
  ctx.setLineDash([10, 8]);
  paths.forEach(p => {
    ctx.beginPath(); ctx.moveTo(p.x1, p.y1); ctx.lineTo(p.x2, p.y2); ctx.stroke();
  });
  ctx.setLineDash([]);

  // Buildings
  buildings.forEach(b => {
    const isFiltered = activeFilter !== 'all' && b.type !== activeFilter;
    const isHovered = hoveredBuilding && hoveredBuilding.id === b.id;
    const isHighlighted = highlightedId === b.id;
    const col = colors[b.type];
    const alpha = isFiltered ? 0.2 : 1;

    ctx.globalAlpha = alpha;

    // Shadow
    if (!isFiltered) {
      ctx.shadowColor = col.stroke;
      ctx.shadowBlur = (isHovered || isHighlighted) ? 20 : 6;
    }

    // Fill
    ctx.fillStyle = isHighlighted ? col.stroke + '55' : col.fill;
    ctx.strokeStyle = col.stroke;
    ctx.lineWidth = (isHovered || isHighlighted) ? 2.5 : 1.5;

    roundRect(ctx, b.x, b.y, b.w, b.h, 8);
    ctx.fill();
    ctx.stroke();
    ctx.shadowBlur = 0;

    // Icon
    ctx.font = '18px serif';
    ctx.textAlign = 'center';
    ctx.fillStyle = col.label;
    ctx.fillText(b.icon, b.x + b.w / 2, b.y + b.h / 2 - 8);

    // Label
    ctx.font = 'bold 11px "DM Sans", sans-serif';
    ctx.fillStyle = isDark() ? '#e8ecf4' : '#141824';
    ctx.fillText(b.name, b.x + b.w / 2, b.y + b.h / 2 + 10);

    // Floor
    ctx.font = '10px "DM Sans", sans-serif';
    ctx.fillStyle = col.label;
    ctx.fillText('F: ' + b.floor, b.x + b.w / 2, b.y + b.h / 2 + 24);

    ctx.globalAlpha = 1;
  });

  // Compass
  drawCompass(W - 50, 50);

  // Scale
  ctx.fillStyle = isDark() ? 'rgba(255,255,255,0.5)' : 'rgba(0,0,0,0.4)';
  ctx.font = '10px DM Sans';
  ctx.textAlign = 'left';
  ctx.fillText('0        100m       200m', 20, H - 16);
  ctx.strokeStyle = isDark() ? 'rgba(255,255,255,0.5)' : 'rgba(0,0,0,0.4)';
  ctx.lineWidth = 1.5;
  ctx.beginPath(); ctx.moveTo(20, H - 25); ctx.lineTo(140, H - 25); ctx.stroke();
}

function drawCompass(x, y) {
  ctx.save();
  ctx.translate(x, y);
  ctx.fillStyle = '#00e5a0';
  ctx.font = 'bold 14px Syne';
  ctx.textAlign = 'center';
  ctx.fillText('N', 0, -18);
  ctx.strokeStyle = '#00e5a0';
  ctx.lineWidth = 2;
  ctx.beginPath(); ctx.moveTo(0, -14); ctx.lineTo(0, 14); ctx.stroke();
  ctx.beginPath(); ctx.moveTo(-14, 0); ctx.lineTo(14, 0); ctx.stroke();
  ctx.restore();
}

function roundRect(ctx, x, y, w, h, r) {
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.lineTo(x + w - r, y);
  ctx.quadraticCurveTo(x + w, y, x + w, y + r);
  ctx.lineTo(x + w, y + h - r);
  ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
  ctx.lineTo(x + r, y + h);
  ctx.quadraticCurveTo(x, y + h, x, y + h - r);
  ctx.lineTo(x, y + r);
  ctx.quadraticCurveTo(x, y, x + r, y);
  ctx.closePath();
}

// ─── INTERACTION ──────────────────────────────────────────
function getBuilding(mx, my) {
  const rect = canvas.getBoundingClientRect();
  const cw = canvas.width, ch = canvas.height;
  const sx = cw / rect.width, sy = ch / rect.height;
  const cx = mx * sx, cy = my * sy;

  return buildings.find(b => cx >= b.x && cx <= b.x + b.w && cy >= b.y && cy <= b.y + b.h) || null;
}

function initMap() {
  canvas = document.getElementById('campusMap');
  if (!canvas) return;
  ctx = canvas.getContext('2d');
  drawMap();

  // Hover
  canvas.addEventListener('mousemove', e => {
    const rect = canvas.getBoundingClientRect();
    const b = getBuilding(e.clientX - rect.left, e.clientY - rect.top);
    hoveredBuilding = b;
    canvas.style.cursor = b ? 'pointer' : 'crosshair';

    if (b) showTooltip(e, b);
    else hideTooltip();

    drawMap();
  });

  canvas.addEventListener('mouseleave', () => {
    hoveredBuilding = null;
    hideTooltip();
    drawMap();
  });

  canvas.addEventListener('click', e => {
    const rect = canvas.getBoundingClientRect();
    const b = getBuilding(e.clientX - rect.left, e.clientY - rect.top);
    if (b) {
      highlightedId = b.id;
      drawMap();
    }
  });

  // Filters
  document.querySelectorAll('.map-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.map-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      activeFilter = btn.dataset.filter;
      drawMap();
    });
  });
}

function showTooltip(e, b) {
  const tooltip = document.getElementById('mapTooltip');
  const rect = canvas.getBoundingClientRect();
  const cw = canvas.width, ch = canvas.height;
  const sx = cw / rect.width;

  const cx = (b.x + b.w / 2) / sx;
  let tx = cx + rect.left - canvas.getBoundingClientRect().left;

  tooltip.querySelector('.tooltip-name').textContent = b.icon + ' ' + b.name;
  tooltip.querySelector('.tooltip-meta').textContent = b.desc + ' · Floor ' + b.floor;
  tooltip.dataset.buildingName = b.name;

  const sy = ch / rect.height;
  const ty = (b.y + b.h) / sy;

  tooltip.style.left = (b.x / sx + 10) + 'px';
  tooltip.style.top = (ty + 8) + 'px';
  tooltip.classList.add('visible');
}

function hideTooltip() {
  document.getElementById('mapTooltip')?.classList.remove('visible');
}

function highlightBuilding(name) {
  const b = buildings.find(b => b.name.toLowerCase().includes(name.toLowerCase()));
  if (b) {
    highlightedId = b.id;
    drawMap();
    canvas.scrollIntoView({ behavior: 'smooth', block: 'center' });
  }
}

// Theme changes
document.addEventListener('themeChanged', () => drawMap());

window.addEventListener('load', initMap);
window.addEventListener('resize', () => drawMap());
